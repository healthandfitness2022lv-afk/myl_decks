"""Escribe en Firestore las habilidades de las 4 cartas Sacerdote pendientes.

Uso (desde simulator/):
    set PYTHONPATH=. && .venv\\Scripts\\python cache\\meta\\escribir_sacer.py cache\\meta\\cartas_sacer_habilidades.json

Respaldo de los documentos originales: cache/meta/cartas_sacer_pendientes.json
"""
import json
import sys

from myl_sim.datos import carta_desde_doc, db

H = json.load(open(sys.argv[1], encoding="utf-8"))
d = db()
for cid, habs in H.items():
    ref = d.collection("cards").document(cid)
    ref.update({"habilidades": habs, "habilidadesRevisadas": True})
    x = ref.get().to_dict()
    c = carta_desde_doc(cid, x)
    print(cid, "revisadas:", x.get("habilidadesRevisadas"), "habs:", len(x.get("habilidades") or []),
          "programada:", c.programada)

# Matriz del meta · raciales del caché

42 mazos · 20 partidas por cruce · jugador `heuristico` · motor `7b0bad4f3f6ef6c4`

## Ranking (winrate esperado contra el meta)

Score: contra los pesos del meta (iguales si no hay datos). Meta evolutivo: contra el meta que resulta si los jugadores se pasan a lo que gana (10 generaciones); % evol = cuánto se jugaría cada mazo.

| # | Mazo | Score | IC95 | Meta evolutivo | % evol | Peores cruces |
|---|---|---|---|---|---|---|
| 1 | Pato Killer top 32 | 68.9% | 66.1–71.8 | 57.0% | 9% | Druida (03bV) 40%, Leo Caballero 40%, Faraon (KgX2) 40% |
| 2 | Faraón guerrero | 66.7% | 63.7–69.6 | 56.5% | 8% | Djoser - Guerrero 40%, Héroe 45%, Caballero Armas 45% |
| 3 | Faraon (KgX2) | 66.5% | 63.6–69.5 | 57.5% | 9% | Leo Caballero 35%, Sacerdote (iPlH) 40%, Caballero Armas 50% |
| 4 | Faraon (E4FX) | 65.3% | 62.3–68.3 | 54.4% | 6% | Caballero Armas 40%, Djoser - Guerrero 40%, Faraón guerrero 40% |
| 5 | Djoser - Guerrero | 65.3% | 62.3–68.3 | 54.1% | 5% | Pato Killer top 32 30%, Leo Caballero 30%, Sacerdo Premier 40% |
| 6 | Sacerdote (iPlH) | 65.2% | 62.3–68.2 | 53.6% | 4% | Hector Faraon Guerrero 30%, Pato Killer top 32 35%, Leo Caballero 40% |
| 7 | Hector Faraon Guerrero | 65.0% | 62.1–67.9 | 53.7% | 5% | Druida (3RIn) 35%, Druida (03bV) 40%, Guille Caballero 40% |
| 8 | Caballero Plaga | 64.8% | 61.7–67.8 | 56.4% | 7% | Faraon (E4FX) 40%, Faraon (KgX2) 45%, Eterno Control 45% |
| 9 | Caballero Armas | 62.5% | 59.4–65.6 | 54.8% | 5% | Pato Killer top 32 35%, Titán Minotauro 40%, SACER PREMIER DOMINIOS DE RA 45% |
| 10 | Cesar Sacerdote | 62.1% | 59.1–65.1 | 51.4% | 3% | Hector Faraon Guerrero 30%, Faraón guerrero 30%, Faraon (E4FX) 35% |
| 11 | Sacerdo Premier | 62.0% | 59.0–65.0 | 50.5% | 3% | Faraon (E4FX) 30%, Sombra Agro 30%, Caballero Plaga 30% |
| 12 | sacerdote top 16 especial ra | 61.5% | 58.5–64.5 | 48.0% | 2% | Cesar Sacerdote 20%, Hector Faraon Guerrero 30%, Faraón guerrero 30% |
| 13 | Leo Caballero | 61.3% | 58.2–64.4 | 57.0% | 6% | Erick Dragon 30%, Dragón 35%, Cesar Sacerdote 35% |
| 14 | Héroe | 60.8% | 57.7–63.8 | 47.6% | 2% | Faraon (KgX2) 25%, Pato Killer top 32 30%, Faraon (E4FX) 35% |
| 15 | Guille Caballero | 60.4% | 57.3–63.4 | 50.9% | 3% | Erick Dragon 30%, Leo Caballero 35%, sacerdote top 16 especial ra 35% |
| 16 | SACER PREMIER DOMINIOS DE RA | 56.4% | 53.4–59.5 | 44.4% | 1% | Hector Faraon Guerrero 25%, Pato Killer top 32 25%, Guille Sombra 30% |
| 17 | Sacerdote | 56.4% | 53.4–59.4 | 42.1% | 1% | Hector Faraon Guerrero 20%, Héroe 25%, Caballero Plaga 25% |
| 18 | Erick Dragon | 54.6% | 51.7–57.6 | 46.7% | 1% | SACER PREMIER DOMINIOS DE RA 15%, sacerdote top 16 especial ra 15%, Sacerdo Premier 20% |
| 19 | Sombra Agro | 53.9% | 50.9–57.0 | 40.5% | 1% | Guille Caballero 15%, Caballero Armas 15%, Hector Faraon Guerrero 25% |
| 20 | Titán Minotauro | 53.7% | 50.6–56.8 | 42.8% | 1% | Héroe 25%, Faraon (KgX2) 30%, Pato Killer top 32 30% |
| 21 | Nasho Auditore Dragon | 51.3% | 48.3–54.4 | 40.8% | 1% | Sacerdo Premier 15%, Djoser - Guerrero 20%, sacerdote top 16 especial ra 20% |
| 22 | Dragón | 50.7% | 47.7–53.7 | 38.0% | 1% | Faraon (E4FX) 15%, Sacerdote (iPlH) 15%, Faraón guerrero 15% |
| 23 | Eterno Control | 48.0% | 44.8–51.1 | 40.9% | 1% | Cesar Sacerdote 15%, Sacerdo Premier 20%, Pato Killer top 32 20% |
| 24 | Guille Sombra | 47.6% | 44.5–50.8 | 37.3% | 1% | Djoser - Guerrero 15%, Faraon (E4FX) 25%, Dragón 25% |
| 25 | Defensor | 46.9% | 43.8–50.0 | 36.2% | 1% | Faraon (E4FX) 15%, Hector Faraon Guerrero 15%, Leo Caballero 20% |
| 26 | Faraón Djoser | 46.6% | 43.5–49.7 | 34.5% | 1% | Sacerdote (iPlH) 15%, Hector Faraon Guerrero 20%, Caballero Armas 20% |
| 27 | Hector faraon | 45.8% | 42.7–49.0 | 35.4% | 1% | Faraón guerrero 15%, Cesar Sacerdote 20%, Guille Caballero 25% |
| 28 | Druida (03bV) | 45.2% | 42.2–48.3 | 42.3% | 1% | Nasho Auditore Dragon 10%, sacerdote top 16 especial ra 15%, SACER PREMIER DOMINIOS DE RA 20% |
| 29 | Eterno Agro | 44.4% | 41.4–47.4 | 31.3% | 1% | Djoser - Guerrero 15%, Guille Caballero 20%, Faraon (KgX2) 20% |
| 30 | Olimpico | 44.4% | 41.3–47.5 | 30.1% | 1% | Faraón guerrero 10%, Faraon (E4FX) 10%, Hector Faraon Guerrero 10% |
| 31 | Druida (3RIn) | 44.2% | 41.1–47.2 | 38.3% | 1% | Erick Dragon 10%, Sacerdote 15%, Sacerdote (iPlH) 15% |
| 32 | Desafiante Plaga | 41.2% | 38.1–44.3 | 33.3% | 1% | Caballero Armas 15%, Druida (03bV) 20%, Faraon (KgX2) 20% |
| 33 | Druida Premier 10 de Octubre | 40.6% | 37.6–43.6 | 37.0% | 1% | Guille Caballero 5%, Dragón 10%, Sacerdo Premier 10% |
| 34 | Leo Defensor Druida | 40.5% | 37.3–43.6 | 35.1% | 1% | Sacerdote (iPlH) 10%, Erick Dragon 15%, Dragón 20% |
| 35 | Faerie Goblin | 39.2% | 36.2–42.2 | 27.0% | 1% | Guille Caballero 10%, Faraon (KgX2) 10%, Titán Minotauro 10% |
| 36 | Titanes | 35.6% | 32.6–38.6 | 28.2% | 1% | Cesar Sacerdote 10%, Hector Faraon Guerrero 15%, Defensor 15% |
| 37 | Faerie Control | 34.7% | 31.9–37.5 | 21.9% | 1% | Cesar Sacerdote 0%, Pato Killer top 32 0%, Hector Faraon Guerrero 10% |
| 38 | Erick Faire | 29.8% | 27.0–32.5 | 17.4% | 1% | Faraon (E4FX) 0%, Pato Killer top 32 0%, Faraón guerrero 0% |
| 39 | Auditore Faire | 28.7% | 26.0–31.4 | 16.6% | 1% | Faraon (KgX2) 0%, Djoser - Guerrero 0%, Hector Faraon Guerrero 5% |
| 40 | Desafiante Control | 26.8% | 24.1–29.5 | 19.3% | 1% | Djoser - Guerrero 3%, Caballero Armas 5%, Sacerdote (iPlH) 5% |
| 41 | Desafiante MidRange | 26.0% | 23.3–28.7 | 19.9% | 1% | Sacerdo Premier 5%, Caballero Armas 5%, Pato Killer top 32 5% |
| 42 | Sombra Control | 8.5% | 6.7–10.2 | 4.3% | 1% | Leo Caballero 0%, Faraon (E4FX) 0%, Héroe 0% |

## Equilibrio (la mezcla que nadie de la lista le gana)

Caballero Plaga 29%, Caballero Armas 19%, Faraon (E4FX) 15%, Leo Caballero 14%, Sacerdote (iPlH) 8%, Faraon (KgX2) 8%, Pato Killer top 32 7%

## Matriz (winrate de la fila contra la columna)

| | Pato Kille | Faraón gue | Faraon (Kg | Faraon (E4 | Djoser - G | Sacerdote  | Hector Far | Caballero  | Caballero  | Cesar Sace | Sacerdo Pr | sacerdote  | Leo Caball | Héroe | Guille Cab | SACER PREM | Sacerdote | Erick Drag | Sombra Agr | Titán Mino | Nasho Audi | Dragón | Eterno Con | Guille Som | Defensor | Faraón Djo | Hector far | Druida (03 | Eterno Agr | Olimpico | Druida (3R | Desafiante | Druida Pre | Leo Defens | Faerie Gob | Titanes | Faerie Con | Erick Fair | Auditore F | Desafiante | Desafiante | Sombra Con |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| Pato Killer top 32 | — | 45 | 40 | 55 | 70 | 65 | 50 | 40 | 65 | 50 | 55 | 60 | 40 | 70 | 60 | 75 | 65 | 50 | 70 | 70 | 70 | 75 | 80 | 75 | 70 | 75 | 70 | 40 | 80 | 85 | 65 | 80 | 80 | 65 | 85 | 75 | 100 | 100 | 95 | 90 | 95 | 100 |
| Faraón guerrero | 55 | — | 50 | 60 | 40 | 45 | 55 | 45 | 45 | 70 | 50 | 70 | 50 | 45 | 55 | 70 | 70 | 70 | 70 | 70 | 65 | 85 | 65 | 70 | 50 | 80 | 85 | 55 | 75 | 90 | 65 | 80 | 60 | 60 | 75 | 55 | 80 | 100 | 90 | 90 | 90 | 100 |
| Faraon (KgX2) | 60 | 50 | — | 55 | 55 | 40 | 60 | 55 | 50 | 55 | 65 | 65 | 35 | 75 | 55 | 60 | 60 | 60 | 70 | 70 | 75 | 75 | 50 | 65 | 65 | 70 | 75 | 60 | 80 | 85 | 75 | 80 | 50 | 65 | 90 | 80 | 80 | 90 | 100 | 65 | 80 | 95 |
| Faraon (E4FX) | 45 | 40 | 45 | — | 40 | 55 | 50 | 60 | 40 | 65 | 70 | 65 | 45 | 65 | 50 | 45 | 70 | 75 | 60 | 65 | 65 | 85 | 65 | 75 | 85 | 80 | 75 | 55 | 75 | 90 | 60 | 55 | 65 | 70 | 70 | 75 | 80 | 100 | 90 | 65 | 62 | 100 |
| Djoser - Guerrero | 30 | 60 | 45 | 60 | — | 60 | 60 | 55 | 45 | 55 | 40 | 50 | 30 | 55 | 45 | 65 | 70 | 65 | 60 | 55 | 80 | 70 | 55 | 85 | 75 | 70 | 75 | 65 | 85 | 70 | 55 | 55 | 65 | 65 | 85 | 75 | 90 | 95 | 100 | 98 | 75 | 100 |
| Sacerdote (iPlH) | 35 | 55 | 60 | 45 | 40 | — | 30 | 55 | 55 | 55 | 40 | 65 | 40 | 50 | 50 | 65 | 55 | 65 | 60 | 55 | 75 | 85 | 65 | 70 | 55 | 85 | 65 | 80 | 65 | 65 | 85 | 65 | 65 | 90 | 75 | 75 | 90 | 95 | 95 | 95 | 75 | 100 |
| Hector Faraon Guerrero | 50 | 45 | 40 | 50 | 40 | 70 | — | 40 | 40 | 70 | 50 | 70 | 50 | 55 | 40 | 75 | 80 | 55 | 75 | 60 | 70 | 60 | 70 | 65 | 85 | 80 | 70 | 40 | 70 | 90 | 35 | 60 | 50 | 70 | 80 | 85 | 90 | 95 | 95 | 85 | 85 | 95 |
| Caballero Plaga | 60 | 55 | 45 | 40 | 45 | 45 | 60 | — | 55 | 50 | 70 | 50 | 55 | 60 | 55 | 50 | 75 | 55 | 75 | 70 | 50 | 60 | 45 | 70 | 65 | 60 | 65 | 75 | 75 | 80 | 65 | 65 | 65 | 70 | 75 | 85 | 80 | 80 | 85 | 90 | 95 | 100 |
| Caballero Armas | 35 | 55 | 50 | 60 | 55 | 45 | 60 | 45 | — | 45 | 50 | 50 | 60 | 60 | 60 | 45 | 65 | 45 | 85 | 40 | 50 | 50 | 50 | 75 | 80 | 80 | 50 | 50 | 75 | 65 | 70 | 85 | 60 | 75 | 85 | 70 | 70 | 70 | 70 | 95 | 95 | 95 |
| Cesar Sacerdote | 50 | 30 | 45 | 35 | 45 | 45 | 30 | 50 | 55 | — | 45 | 80 | 65 | 55 | 50 | 65 | 50 | 60 | 40 | 65 | 60 | 55 | 85 | 35 | 70 | 50 | 80 | 55 | 65 | 75 | 60 | 80 | 65 | 65 | 80 | 90 | 100 | 85 | 85 | 90 | 80 | 90 |
| Sacerdo Premier | 45 | 50 | 35 | 30 | 60 | 60 | 50 | 30 | 50 | 55 | — | 55 | 40 | 40 | 50 | 60 | 55 | 80 | 30 | 60 | 85 | 75 | 80 | 60 | 60 | 60 | 65 | 70 | 75 | 50 | 80 | 65 | 90 | 60 | 60 | 80 | 90 | 75 | 80 | 75 | 95 | 90 |
| sacerdote top 16 especial ra | 40 | 30 | 35 | 35 | 50 | 35 | 30 | 50 | 50 | 20 | 45 | — | 55 | 65 | 65 | 60 | 65 | 85 | 40 | 55 | 80 | 80 | 70 | 45 | 75 | 80 | 65 | 85 | 55 | 50 | 85 | 65 | 65 | 70 | 80 | 70 | 88 | 75 | 95 | 85 | 60 | 100 |
| Leo Caballero | 60 | 50 | 65 | 55 | 70 | 60 | 50 | 45 | 40 | 35 | 60 | 45 | — | 55 | 65 | 65 | 55 | 30 | 60 | 55 | 40 | 35 | 65 | 55 | 80 | 60 | 55 | 75 | 75 | 60 | 65 | 70 | 65 | 65 | 70 | 80 | 80 | 70 | 75 | 90 | 75 | 100 |
| Héroe | 30 | 55 | 25 | 35 | 45 | 50 | 45 | 40 | 40 | 45 | 60 | 35 | 45 | — | 50 | 55 | 75 | 50 | 60 | 75 | 55 | 55 | 55 | 55 | 70 | 62 | 65 | 80 | 70 | 60 | 65 | 65 | 85 | 70 | 80 | 75 | 85 | 80 | 90 | 75 | 90 | 100 |
| Guille Caballero | 40 | 45 | 45 | 50 | 55 | 50 | 60 | 45 | 40 | 50 | 50 | 35 | 35 | 50 | — | 50 | 60 | 30 | 85 | 55 | 50 | 60 | 60 | 70 | 60 | 60 | 75 | 60 | 80 | 55 | 50 | 65 | 95 | 70 | 90 | 70 | 70 | 80 | 80 | 90 | 70 | 95 |
| SACER PREMIER DOMINIOS DE RA | 25 | 30 | 40 | 55 | 35 | 35 | 25 | 50 | 55 | 35 | 40 | 40 | 35 | 45 | 50 | — | 55 | 85 | 45 | 35 | 70 | 65 | 70 | 30 | 75 | 60 | 55 | 80 | 60 | 65 | 60 | 80 | 70 | 50 | 60 | 75 | 65 | 80 | 70 | 80 | 85 | 100 |
| Sacerdote | 35 | 30 | 40 | 30 | 30 | 45 | 20 | 25 | 35 | 50 | 45 | 35 | 45 | 25 | 40 | 45 | — | 75 | 50 | 40 | 65 | 75 | 70 | 45 | 65 | 75 | 50 | 75 | 70 | 45 | 85 | 65 | 85 | 60 | 65 | 75 | 85 | 85 | 90 | 65 | 88 | 95 |
| Erick Dragon | 50 | 30 | 40 | 25 | 35 | 35 | 45 | 45 | 55 | 40 | 20 | 15 | 70 | 50 | 70 | 15 | 25 | — | 55 | 55 | 60 | 65 | 30 | 60 | 60 | 45 | 50 | 70 | 40 | 60 | 90 | 70 | 85 | 85 | 35 | 60 | 85 | 65 | 70 | 95 | 95 | 95 |
| Sombra Agro | 30 | 30 | 30 | 40 | 40 | 40 | 25 | 25 | 15 | 60 | 70 | 60 | 40 | 40 | 15 | 55 | 50 | 45 | — | 40 | 75 | 70 | 70 | 60 | 30 | 70 | 55 | 50 | 65 | 80 | 70 | 55 | 45 | 45 | 65 | 70 | 90 | 75 | 80 | 75 | 80 | 90 |
| Titán Minotauro | 30 | 30 | 30 | 35 | 45 | 45 | 40 | 30 | 60 | 35 | 40 | 45 | 45 | 25 | 45 | 65 | 60 | 45 | 60 | — | 35 | 45 | 45 | 60 | 45 | 70 | 50 | 50 | 65 | 45 | 55 | 80 | 70 | 80 | 90 | 70 | 70 | 65 | 60 | 70 | 90 | 85 |
| Nasho Auditore Dragon | 30 | 35 | 25 | 35 | 20 | 25 | 30 | 50 | 50 | 40 | 15 | 20 | 60 | 45 | 50 | 30 | 35 | 40 | 25 | 65 | — | 40 | 50 | 45 | 65 | 60 | 45 | 90 | 45 | 55 | 75 | 70 | 85 | 70 | 60 | 55 | 70 | 75 | 75 | 85 | 75 | 90 |
| Dragón | 25 | 15 | 25 | 15 | 30 | 15 | 40 | 40 | 50 | 45 | 25 | 20 | 65 | 45 | 40 | 35 | 25 | 35 | 30 | 55 | 60 | — | 45 | 75 | 35 | 35 | 65 | 70 | 70 | 50 | 50 | 75 | 90 | 80 | 60 | 65 | 60 | 80 | 70 | 85 | 85 | 100 |
| Eterno Control | 20 | 35 | 50 | 35 | 45 | 35 | 30 | 55 | 50 | 15 | 20 | 30 | 35 | 45 | 40 | 30 | 30 | 70 | 30 | 55 | 50 | 55 | — | 45 | 55 | 20 | 45 | 65 | 50 | 45 | 50 | 45 | 60 | 50 | 75 | 70 | 60 | 70 | 60 | 80 | 70 | 90 |
| Guille Sombra | 25 | 30 | 35 | 25 | 15 | 30 | 35 | 30 | 25 | 65 | 40 | 55 | 45 | 45 | 30 | 70 | 55 | 40 | 40 | 40 | 55 | 25 | 55 | — | 45 | 70 | 55 | 30 | 50 | 40 | 50 | 50 | 50 | 55 | 60 | 50 | 75 | 80 | 65 | 60 | 60 | 95 |
| Defensor | 30 | 50 | 35 | 15 | 25 | 45 | 15 | 35 | 20 | 30 | 40 | 25 | 20 | 30 | 40 | 25 | 35 | 40 | 70 | 55 | 35 | 65 | 45 | 55 | — | 50 | 50 | 45 | 70 | 70 | 35 | 45 | 40 | 70 | 50 | 85 | 55 | 80 | 60 | 75 | 60 | 100 |
| Faraón Djoser | 25 | 20 | 30 | 20 | 30 | 15 | 20 | 40 | 20 | 50 | 40 | 20 | 40 | 38 | 40 | 40 | 25 | 55 | 30 | 30 | 40 | 65 | 80 | 30 | 50 | — | 65 | 50 | 60 | 55 | 70 | 60 | 80 | 65 | 40 | 65 | 50 | 75 | 75 | 60 | 50 | 95 |
| Hector faraon | 30 | 15 | 25 | 25 | 25 | 35 | 30 | 35 | 50 | 20 | 35 | 35 | 45 | 35 | 25 | 45 | 50 | 50 | 45 | 50 | 55 | 35 | 55 | 45 | 50 | 35 | — | 40 | 65 | 60 | 45 | 75 | 35 | 60 | 55 | 55 | 45 | 70 | 55 | 70 | 75 | 90 |
| Druida (03bV) | 60 | 45 | 40 | 45 | 35 | 20 | 60 | 25 | 50 | 45 | 30 | 15 | 25 | 20 | 40 | 20 | 25 | 30 | 50 | 50 | 10 | 30 | 35 | 70 | 55 | 50 | 60 | — | 30 | 55 | 45 | 80 | 40 | 55 | 55 | 70 | 30 | 30 | 60 | 85 | 85 | 90 |
| Eterno Agro | 20 | 25 | 20 | 25 | 15 | 35 | 30 | 25 | 25 | 35 | 25 | 45 | 25 | 30 | 20 | 40 | 30 | 60 | 35 | 35 | 55 | 30 | 50 | 50 | 30 | 40 | 35 | 70 | — | 40 | 80 | 40 | 50 | 60 | 50 | 75 | 60 | 50 | 95 | 70 | 85 | 100 |
| Olimpico | 15 | 10 | 15 | 10 | 30 | 35 | 10 | 20 | 35 | 25 | 50 | 50 | 40 | 40 | 45 | 35 | 55 | 40 | 20 | 55 | 45 | 50 | 55 | 60 | 30 | 45 | 40 | 45 | 60 | — | 40 | 45 | 45 | 60 | 55 | 60 | 65 | 80 | 65 | 70 | 70 | 95 |
| Druida (3RIn) | 35 | 35 | 25 | 40 | 45 | 15 | 65 | 35 | 30 | 40 | 20 | 15 | 35 | 35 | 50 | 40 | 15 | 10 | 30 | 45 | 25 | 50 | 50 | 50 | 65 | 30 | 55 | 55 | 20 | 60 | — | 50 | 75 | 40 | 45 | 70 | 40 | 55 | 70 | 80 | 75 | 85 |
| Desafiante Plaga | 20 | 20 | 20 | 45 | 45 | 35 | 40 | 35 | 15 | 20 | 35 | 35 | 30 | 35 | 35 | 20 | 35 | 30 | 45 | 20 | 30 | 25 | 55 | 50 | 55 | 40 | 25 | 20 | 60 | 55 | 50 | — | 45 | 55 | 40 | 35 | 60 | 50 | 70 | 85 | 65 | 95 |
| Druida Premier 10 de Octubre | 20 | 40 | 50 | 35 | 35 | 35 | 50 | 35 | 40 | 35 | 10 | 35 | 35 | 15 | 5 | 30 | 15 | 15 | 55 | 30 | 15 | 10 | 40 | 50 | 60 | 20 | 65 | 60 | 50 | 55 | 25 | 55 | — | 50 | 65 | 40 | 70 | 55 | 50 | 70 | 70 | 60 |
| Leo Defensor Druida | 35 | 40 | 35 | 30 | 35 | 10 | 30 | 30 | 25 | 35 | 40 | 30 | 35 | 30 | 30 | 50 | 40 | 15 | 55 | 20 | 30 | 20 | 50 | 45 | 30 | 35 | 40 | 45 | 40 | 40 | 60 | 45 | 50 | — | 50 | 50 | 55 | 50 | 40 | 75 | 70 | 80 |
| Faerie Goblin | 15 | 25 | 10 | 30 | 15 | 25 | 20 | 25 | 15 | 20 | 40 | 20 | 30 | 20 | 10 | 40 | 35 | 65 | 35 | 10 | 40 | 40 | 25 | 40 | 50 | 60 | 45 | 45 | 50 | 45 | 55 | 60 | 35 | 50 | — | 50 | 55 | 65 | 65 | 70 | 55 | 90 |
| Titanes | 25 | 45 | 20 | 25 | 25 | 25 | 15 | 15 | 30 | 10 | 20 | 30 | 20 | 25 | 30 | 25 | 25 | 40 | 30 | 30 | 45 | 35 | 30 | 50 | 15 | 35 | 45 | 30 | 25 | 40 | 30 | 65 | 60 | 50 | 50 | — | 35 | 40 | 55 | 55 | 60 | 85 |
| Faerie Control | 0 | 20 | 20 | 20 | 10 | 10 | 10 | 20 | 30 | 0 | 10 | 12 | 20 | 15 | 30 | 35 | 15 | 15 | 10 | 30 | 30 | 40 | 40 | 25 | 45 | 50 | 55 | 70 | 40 | 35 | 60 | 40 | 30 | 45 | 45 | 65 | — | 65 | 75 | 55 | 85 | 80 |
| Erick Faire | 0 | 0 | 10 | 0 | 5 | 5 | 5 | 20 | 30 | 15 | 25 | 25 | 30 | 20 | 20 | 20 | 15 | 35 | 25 | 35 | 25 | 20 | 30 | 20 | 20 | 25 | 30 | 70 | 50 | 20 | 45 | 50 | 45 | 50 | 35 | 60 | 35 | — | 45 | 45 | 60 | 80 |
| Auditore Faire | 5 | 10 | 0 | 10 | 0 | 5 | 5 | 15 | 30 | 15 | 20 | 5 | 25 | 10 | 20 | 30 | 10 | 30 | 20 | 40 | 25 | 30 | 40 | 35 | 40 | 25 | 45 | 40 | 5 | 35 | 30 | 30 | 50 | 60 | 35 | 45 | 25 | 55 | — | 45 | 60 | 95 |
| Desafiante Control | 10 | 10 | 35 | 35 | 2 | 5 | 15 | 10 | 5 | 10 | 25 | 15 | 10 | 25 | 10 | 20 | 35 | 5 | 25 | 30 | 15 | 15 | 20 | 40 | 25 | 40 | 30 | 15 | 30 | 30 | 20 | 15 | 30 | 25 | 30 | 45 | 45 | 55 | 55 | — | 62 | 95 |
| Desafiante MidRange | 5 | 10 | 20 | 38 | 25 | 25 | 15 | 5 | 5 | 20 | 5 | 40 | 25 | 10 | 30 | 15 | 12 | 5 | 20 | 10 | 25 | 15 | 30 | 40 | 40 | 50 | 25 | 15 | 15 | 30 | 25 | 35 | 30 | 30 | 45 | 40 | 15 | 40 | 40 | 38 | — | 80 |
| Sombra Control | 0 | 0 | 5 | 0 | 0 | 0 | 5 | 0 | 5 | 10 | 10 | 0 | 0 | 0 | 5 | 0 | 5 | 5 | 10 | 15 | 10 | 0 | 10 | 5 | 0 | 5 | 10 | 10 | 0 | 5 | 15 | 5 | 40 | 20 | 10 | 15 | 20 | 20 | 5 | 5 | 20 | — |

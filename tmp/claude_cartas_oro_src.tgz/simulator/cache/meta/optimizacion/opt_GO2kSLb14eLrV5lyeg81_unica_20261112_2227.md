# Optimización · Sacer Totem (−Gran Guardian +Akhet)

Rivales: 42 mazos del meta · cartas a probar: mazos de la raza · copias máximas: Ban List

## Ronda 1

Winrate base contra el meta: 50.0%

| Cambio | Diferencia | IC95 | Dónde gana / pierde más |
|---|---|---|---|
| −Asheru +Demoledor de Amon | +2.1 pts | +0.4 a +3.8 | Nasho Auditore Dragon +13, Erick Dragon +10, Dragón -20, Sacerdote -7 |
| −Mercado Egipcio +Lanza De Osiris | +1.8 pts | +0.1 a +3.5 | Faerie Goblin +10, Djoser - Guerrero +10, SACER PREMIER DOMINIOS DE RA -17, Erick Dragon -13 |
| −Escarabeo +Toro Apis | +0.6 pts | -0.5 a +1.7 | Eterno Control +10, Caballero Armas +10, Druida Premier 10 de Octubre -10, Héroe -7 |

**Aceptado:** −Asheru +Demoledor de Amon

## Lista final

- 1× Abismo
- 1× Abu Simbel
- 3× Akhet
- 2× Amkh
- 1× Asheru
- 3× Ayu
- 2× Ayu del Veneno
- 1× Bennu
- 2× Busto Imperial
- 1× Demoledor de Amon
- 2× Djedefhor
- 1× Duat
- 1× Escarabeo
- 3× Flechas de Lava
- 2× Haquika
- 3× Ib-Mut
- 2× Iuwlot
- 1× Jeroglificos
- 1× Jinetes de Fuego
- 3× Kawit
- 1× Mercado Egipcio
- 2× Papiros de Lahun
- 1× Piedra Roseta
- 1× Qadesh
- 1× Resplandor de Heka
- 1× Rito de Aton
- 2× Riton Aqueménida
- 2× Saqqara
- 1× Tebas
- 1× Wep Renpet

Validación Ban List + Única: OK

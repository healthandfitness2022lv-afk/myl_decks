# Optimización · Sacerdote

Rivales: 24 mazos del meta · cartas a probar: side deck · copias máximas: Ban List

## Ronda 1

Winrate base contra el meta: 61.1%

| Cambio | Diferencia | IC95 | Dónde gana / pierde más |
|---|---|---|---|
| −Mercado Egipcio +Aton | +1.6 pts | -0.8 a +3.9 | Desafiante Plaga +18, Eterno Control +10, Djoser - Guerrero -10, sacerdote top 16 especial ra -8 |
| −Nacer De La Muerte +Invocar Chacales | +1.5 pts | -0.2 a +3.1 | Eterno Control +10, Titán Minotauro +8, Pato Killer top 32 -5, Desafiante Plaga -2 |
| −Nacer De La Muerte +Aton | +1.0 pts | -0.9 a +3.0 | Eterno Control +8, Sombra Agro +5, Eterno Agro -10, Faerie Control -5 |

**Aceptado:** ninguno (sin ventaja significativa)


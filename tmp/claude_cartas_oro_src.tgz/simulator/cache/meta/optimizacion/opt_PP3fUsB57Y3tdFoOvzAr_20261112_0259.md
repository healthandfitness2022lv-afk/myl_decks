# Optimización · Sacerdote

Rivales: 63 mazos del meta · cartas a probar: side deck (primero) + mazos de la raza · copias máximas: Ban List

## Ronda 1

Winrate base contra el meta: 62.5%

| Cambio | Diferencia | IC95 | Dónde gana / pierde más |
|---|---|---|---|
| −Mercado Egipcio +Aton | +2.0 pts | +0.6 a +3.4 | Desafiante Plaga +18, Leo Caballero +15, Djoser - Guerrero -10, Eduardo Eterno -10 |
| −Takelot +Tuthu | +1.1 pts | +0.2 a +2.1 | Leo Caballero +10, Nasho Auditore Dragon +10, Desafiante MidRange -8, Leo Titrans -8 |
| −Gran Guardian +Aton | +0.6 pts | -0.6 a +1.7 | Cesar Titan Rea Minotauro +8, Druida Premier 10 de Octubre +8, Djoser - Guerrero -10, Sacerdo Premier -10 |

**Aceptado:** −Mercado Egipcio +Aton

## Lista final

- 1× Abismo
- 2× Akhet
- 1× Amkh
- 1× Aton
- 1× Bennu
- 2× Biblioteca Eterna
- 2× Demoledor de Amon
- 1× Djedefhor
- 1× Escarabeo
- 1× Escudo Celestial
- 2× Flechas de Lava
- 1× Gran Guardian
- 2× Haquika
- 2× Ib-Mut
- 1× Jeroglificos
- 1× Jinetes de Fuego
- 3× Kawit
- 1× Lanza De Osiris
- 2× Luz del Saber
- 1× Mandoble De Seth
- 1× Nacer De La Muerte
- 1× Nudo De Isis
- 1× Nuh
- 2× Papiros de Lahun
- 1× Piedra Roseta
- 1× Pili
- 1× Qadesh
- 1× Qer-Her
- 1× Quemar los Templos
- 1× Relámpago Arcano
- 1× Resplandor de Heka
- 1× Rito de Aton
- 1× Riton Aqueménida
- 1× Takelot
- 1× Tocador
- 1× Toro Apis
- 3× Werin el Poseído

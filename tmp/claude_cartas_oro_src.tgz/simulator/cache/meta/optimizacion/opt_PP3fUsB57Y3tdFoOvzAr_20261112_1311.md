# Optimización · Sacerdote

Rivales: 63 mazos del meta · cartas a probar: side deck (primero) + mazos de la raza · copias máximas: Ban List

## Ronda 1

Winrate base contra el meta: 62.4%

| Cambio | Diferencia | IC95 | Dónde gana / pierde más |
|---|---|---|---|
| −Mercado Egipcio +Forma de Lince | +1.2 pts | -0.2 a +2.5 | Otaiza Desafiante +12, faraón bota cartas +12, Druida Premier 10 de Octubre -10, Mazo Dragón -8 |
| −Takelot +Tuthu | +1.1 pts | +0.2 a +2.1 | Leo Caballero +10, Nasho Auditore Dragon +10, Desafiante MidRange -8, Leo Titrans -8 |
| −Mercado Egipcio +Invocar Chacales | +0.7 pts | -0.6 a +2.0 | Guille Sombra +10, Eduardo Eterno +10, Djoser - Guerrero -8, Leo Defensor Druida -8 |

**Aceptado:** −Takelot +Tuthu

## Ronda 2

Winrate base contra el meta: 64.7%

| Cambio | Diferencia | IC95 | Dónde gana / pierde más |
|---|---|---|---|
| −Takelot +Tuthu · −Nacer De La Muerte +Aton | +1.9 pts | +0.7 a +3.2 | Desafiante Plaga +18, Salva Olimpico +12, Defensor -8, Cesar Sacerdote -8 |
| −Takelot +Tuthu · −Resplandor de Heka +Forma de Lince | +1.3 pts | +0.3 a +2.4 | Guayo Faraon +18, faraón bota cartas +8, Guille Caballero -8, Cesar Sacerdote -8 |
| −Takelot +Tuthu · −Escudo Celestial +Forma de Lince | +0.9 pts | -0.0 a +1.8 | Pato Killer top 32 +12, Guayo Faraon +10, Sacerdo Premier -8, SACER PREMIER DOMINIOS DE RA -5 |

**Aceptado:** −Takelot +Tuthu · −Nacer De La Muerte +Aton

## Lista final

- 1× Abismo
- 2× Akhet
- 1× Amkh
- 1× Aton
- 1× Bennu
- 2× Biblioteca Eterna
- 2× Demoledor de Amon
- 1× Djedefhor
- 1× Escarabeo
- 1× Escudo Celestial
- 2× Flechas de Lava
- 1× Gran Guardian
- 2× Haquika
- 2× Ib-Mut
- 1× Jeroglificos
- 1× Jinetes de Fuego
- 3× Kawit
- 1× Lanza De Osiris
- 2× Luz del Saber
- 1× Mandoble De Seth
- 1× Mercado Egipcio
- 1× Nudo De Isis
- 1× Nuh
- 2× Papiros de Lahun
- 1× Piedra Roseta
- 1× Pili
- 1× Qadesh
- 1× Qer-Her
- 1× Quemar los Templos
- 1× Relámpago Arcano
- 1× Resplandor de Heka
- 1× Rito de Aton
- 1× Riton Aqueménida
- 1× Tocador
- 1× Toro Apis
- 1× Tuthu
- 3× Werin el Poseído

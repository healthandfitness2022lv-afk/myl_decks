# Cartas por programar · racial

64 mazos en la app (todos los jugadores + notables) · 39 listos para simular · 25 con cartas pendientes

| Carta | Raza | Mazos que la usan | Copias | Mazos que completa sola |
|---|---|---|---|---|
| Tanutamani | Faraón | 3 | 6 | 2 |
| Juicio de Tutatis |  | 2 | 2 | 1 |
| Ataque de Aliento |  | 1 | 1 | 1 |
| Dragón Cobrizo | Dragón | 1 | 1 | 1 |
| Erastóstenes | Sacerdote | 1 | 2 | 1 |
| Ofrendas al Dragón |  | 1 | 1 | 1 |
| Orión | Héroe | 4 | 7 | 0 |
| Aliento De Anubis |  | 3 | 3 | 0 |
| Antorcha Olímpica |  | 2 | 2 | 0 |
| Cesar Augusto | Héroe | 2 | 2 | 0 |
| Condenados Al Tártaro |  | 2 | 2 | 0 |
| Dario El Grande | Faraón | 2 | 2 | 0 |
| Duat |  | 2 | 2 | 0 |
| Egeo | Héroe | 2 | 2 | 0 |
| Esna |  | 2 | 2 | 0 |
| Kefren | Faraón | 2 | 2 | 0 |
| Keops | Faraón | 2 | 5 | 0 |
| Kom Ombo |  | 2 | 2 | 0 |
| Micerinos | Faraón | 2 | 2 | 0 |
| Mochuelo |  | 2 | 2 | 0 |
| Rey Midas | Héroe | 2 | 2 | 0 |
| Secretos del Chacal |  | 2 | 2 | 0 |
| Seti | Faraón | 2 | 3 | 0 |
| Teti I | Faraón | 2 | 4 | 0 |
| Wep Renpet |  | 2 | 2 | 0 |
| Aaru |  | 1 | 1 | 0 |
| Aguila Imperial |  | 1 | 1 | 0 |
| Anubis | Eterno | 1 | 1 | 0 |
| Aquiles | Héroe | 1 | 1 | 0 |
| Artio | Desafiante | 1 | 1 | 0 |
| Aullido de Furia |  | 1 | 1 | 0 |
| Caorthannach | Sombra | 1 | 1 | 0 |
| Carro Real |  | 1 | 1 | 0 |
| Cerveza Negra |  | 1 | 2 | 0 |
| Clio | Olímpico | 1 | 3 | 0 |
| Crear Talismán |  | 1 | 1 | 0 |
| Cria de Wyrm | Dragón | 1 | 1 | 0 |
| Dearg Due | Sombra | 1 | 2 | 0 |
| Despertar Oscuro |  | 1 | 2 | 0 |
| Dragón de Luz | Dragón | 1 | 1 | 0 |
| Draig Goch | Dragón | 1 | 1 | 0 |
| El Gran Zeus | Olímpico | 1 | 1 | 0 |
| El Oscuro Hades | Olímpico | 1 | 2 | 0 |
| Excalibur |  | 1 | 1 | 0 |
| Fenix | Olímpico | 1 | 2 | 0 |
| Glas Gaibhenenn |  | 1 | 1 | 0 |
| Hemera | Olímpico | 1 | 3 | 0 |
| Las Erinias | Olímpico | 1 | 2 | 0 |
| Las tres Olas |  | 1 | 1 | 0 |
| Liceo |  | 1 | 2 | 0 |
| Lig-na-paiste | Sombra | 1 | 1 | 0 |
| Robar Vellocino |  | 1 | 1 | 0 |
| Sacmis | Eterno | 1 | 1 | 0 |
| Sajones |  | 1 | 1 | 0 |
| Siabhra Sidhe | Desafiante | 1 | 2 | 0 |
| Temistocles | Héroe | 1 | 2 | 0 |
| Templo del Desierto |  | 1 | 1 | 0 |
| Tributo Sangriento |  | 1 | 1 | 0 |
| Vino De La Eternidad |  | 1 | 1 | 0 |

"""Torneo racial: todos contra todos (incluye espejos), N partidas por cruce."""
import json
import os
import random
import sys
import time
from concurrent.futures import ProcessPoolExecutor, as_completed

SIM = r"C:\Users\healt\Desktop\NEXUS\myl_decks\simulator"
sys.path.insert(0, SIM)
os.chdir(SIM)
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "torneo_resultado.json")
N = 20
_M = {}


def _mazo(uid, did):
    from myl_sim.datos import cargar_mazo
    if did not in _M:
        _M[did] = cargar_mazo(uid, did, usar_cache=True)
    return _M[did]


def cruce(uid, a, b, seed):
    from myl_sim.simulacion import simular
    r = simular(_mazo(uid, a), _mazo(uid, b), N, seed=seed)
    return a, b, seed, {k: r.get(k) for k in ("winrateA", "winrateB", "empates", "victoriasA", "victoriasB",
                                               "sinProgramarA", "sinProgramarB", "anomalas", "validas", "ventajaInicial")}


def main():
    from myl_sim.datos import cargar_mazo, listar_mazos, uid_por_email
    uid = uid_por_email("hecturnicolas@gmail.com")
    mazos = [(i, n) for i, n, f in listar_mazos(uid) if f == "racial"]
    for i, _ in mazos:
        cargar_mazo(uid, i)  # versión actual desde la base (deja el caché al día)
    pares = [(mazos[x][0], mazos[y][0]) for x in range(len(mazos)) for y in range(x, len(mazos))]
    print(len(mazos), "mazos,", len(pares), "cruces", flush=True)
    res, t0 = [], time.time()
    with ProcessPoolExecutor(max_workers=max(2, (os.cpu_count() or 4) - 1)) as ex:
        futs = [ex.submit(cruce, uid, a, b, random.randint(1, 10**6)) for a, b in pares]
        for k, f in enumerate(as_completed(futs), 1):
            a, b, seed, r = f.result()
            res.append({"a": a, "b": b, "seed": seed, **r})
            if k % 20 == 0 or k == len(pares):
                json.dump({"mazos": dict(mazos), "n": N, "cruces": res}, open(OUT, "w", encoding="utf-8"),
                          ensure_ascii=False, default=list)
                print(f"{k}/{len(pares)} cruces, {time.time() - t0:.0f} s", flush=True)


if __name__ == "__main__":
    main()

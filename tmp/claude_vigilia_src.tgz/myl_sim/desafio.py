"""Partida humana contra la IA, mediada por un documento de Firestore.

El motor sigue siendo síncrono. ``HumanoRemoto`` detiene ese hilo justo en
cada decisión y ``SesionDesafio`` publica las opciones legales; la app escribe
la respuesta y el hilo continúa. Así las reglas y las decisiones de la IA son
exactamente las mismas que en una simulación normal.
"""

from __future__ import annotations

import json
from pathlib import Path
import time
from typing import Any, Callable
from google.api_core.exceptions import DeadlineExceeded, ServiceUnavailable
from google.api_core.exceptions import RetryError

from . import habilidades as hab
from .busqueda_bloqueos import PoliticaConBusqueda
from .datos import CACHE
from .jugadores import Heuristico
from .politica_meta import jugador_para
from .modelo import Instancia
from .motor import Jugada, Partida
from .simulacion import _sin_ids_reservados, _solo_cambios


def reintentar_red(operacion):
    """Conserva la partida en memoria durante un corte temporal de Firestore."""
    while True:
        try:
            return operacion()
        except (DeadlineExceeded, ServiceUnavailable, RetryError):
            time.sleep(5)


def _carta(inst: Instancia, partida: Partida) -> dict[str, Any]:
    return {
        "id": str(inst.uid),
        "cartaId": inst.carta.id,
        "nombre": inst.nombre,
        "tipo": inst.tipo.value,
        "fuerza": hab.fuerza(partida, inst) if inst.en_juego and inst.tipo.value == "Aliado" else None,
    }


def vista_desafio(partida: Partida, humano: int) -> dict[str, Any]:
    """Estado visible para la persona: jamás filtra la mano rival."""
    lados = []
    for i, jugador in enumerate(partida.e.jugadores):
        defensa = []
        for inst in jugador.defensa:
            carta = _carta(inst, partida)
            carta["puedeAtacar"] = (
                inst.listo and not hab.tiene_prop(partida, inst, "guardian")
                and not hab.tiene_estado(partida, inst, "no_puede_atacar")
            )
            defensa.append(carta)
        lados.append({
            "nombre": jugador.nombre_mazo,
            "castillo": len(jugador.mazo),
            "mano": [_carta(x, partida) for x in jugador.mano] if i == humano else [],
            "manoCantidad": len(jugador.mano),
            "reserva": [_carta(x, partida) for x in jugador.reserva],
            "pagado": [_carta(x, partida) for x in jugador.pagado],
            "defensa": defensa,
            "ataque": [_carta(x, partida) for x in jugador.ataque],
            "apoyo": [_carta(x, partida) for x in jugador.apoyo],
            "cementerio": len(jugador.cementerio),
            "destierro": len(jugador.destierro),
            "cementerioCartas": [_carta(x, partida) for x in jugador.cementerio],
            "destierroCartas": [_carta(x, partida) for x in jugador.destierro],
        })
    return {
        "turno": partida.e.turno,
        "fase": partida.e.fase,
        "activo": partida.e.activo,
        "lados": lados,
        "log": (partida.e.log or [])[-30:],
    }


class HumanoRemoto:
    """Adaptador del contrato de jugadores para una interfaz humana."""

    nombre = "humano"

    def __init__(self, pedir: Callable[[str, list[dict], dict], Any]):
        self._pedir = pedir
        self._oros_pendientes: list[str] | None = None

    def _coste_pendiente(self, p, yo, carta, *, restringidos=False):
        cantidad = p.coste_de(yo, carta)
        if restringidos:
            for r in p.j(yo).oros_restringidos:
                if cantidad and r[0] > 0 and hab.paga_restringido(carta, r):
                    cantidad -= min(r[0], cantidad)
        return max(0, cantidad - p.j(yo).oros_virtuales)

    def _respuesta_con_pago(self, tipo, opciones, config):
        self._oros_pendientes = None
        r = self._pedir(tipo, opciones, config)
        if isinstance(r, dict):
            self._oros_pendientes = [str(x) for x in r["oros"]]
            return r["id"]
        return r

    def quedarse_mano(self, p, yo):
        return self._pedir("mano_inicial", [], {"titulo": "¿Te quedas esta mano?"}) == "quedarse"

    def confirmar_fase(self, p, yo, titulo):
        self._pedir("avance_fase", [], {"titulo": titulo})

    def elegir_jugada(self, p, yo, jugadas):
        opciones = [
            {
                "id": str(k),
                "titulo": str(x),
                "tipoJugada": x.tipo,
                "carta": x.carta.nombre if x.carta else None,
                "cartaUid": str(x.carta.uid) if x.carta else None,
                "cartaTipo": x.carta.tipo.value if x.carta else None,
                "portadorUid": str(x.portador.uid) if x.portador else None,
                "cantidadPago": self._coste_pendiente(p, yo, x.carta, restringidos=True)
                if x.carta is not None and x.tipo == "jugar" else 0,
            }
            for k, x in enumerate(jugadas)
        ]
        accionables = {x.carta.uid for x in jugadas if x.carta is not None}
        motivos = {}
        jug = p.j(yo)
        for inst in jug.mano + jug.reserva + jug.pagado + jug.defensa + jug.ataque + jug.apoyo:
            activadas = [h for h in inst.habilidades if h.get("cuando") == "activada"]
            if not activadas or inst.uid in accionables:
                continue
            h = activadas[0]
            if inst.zona.value == "mano":
                if inst.tipo.value == "Oro":
                    motivo = "Primero baja este Oro en Vigilia; luego podrás activar su habilidad desde la Reserva."
                else:
                    motivo = "Primero juega esta carta. Su habilidad se activa cuando está en juego."
                    if not p.puede_pagar(yo, inst):
                        motivo += f" Necesitas {p.coste_de(yo, inst)} Oros para jugarla."
            elif h.get("fase", "cualquiera") not in ("cualquiera", p.e.fase):
                motivo = f"Esta habilidad se activa en {h['fase']}."
            elif not hab.condicion_ok(p, yo, h):
                c = h.get("condicion") or {}
                if c.get("tipo") == "aliados_raza":
                    motivo = f"Necesitas {c.get('valor', 1)} Aliados {c.get('raza', '')} en juego."
                else:
                    motivo = "No se cumple la condición de la habilidad."
            elif not hab.puede_pagar_costo(p, yo, inst, h):
                costo = h.get("costo") or {}
                if costo.get("barajarMano"):
                    motivo = f"Necesitas {costo['barajarMano']} carta(s) en la mano para barajar como coste."
                else:
                    motivo = "No puedes pagar el coste de esta habilidad."
            elif hab._necesita_objetivo(h) and not hab.candidatos_validos(p, yo, inst, h):
                costo = h.get("costo") or {}
                motivo = ("No hay objetivo legal o faltan cartas en tu Cementerio para pagar su coste."
                          if costo.get("desterrarCementerioSegun") else "No hay un objetivo legal para esta habilidad.")
            else:
                motivo = "Esta habilidad no tiene una activación legal ahora."
            motivos[str(inst.uid)] = motivo
        elegido = int(self._respuesta_con_pago("jugada", opciones, {
            "titulo": "Elige tu jugada",
            "oros": [_carta(x, p) for x in p.j(yo).reserva],
            "motivos": motivos,
        }))
        return jugadas[elegido]

    def elegir_oros(self, p, yo, disponibles, cantidad, carta=None, por=None):
        opciones = [_carta(x, p) for x in disponibles]
        titulo = f"Paga {cantidad} Oro{'s' if cantidad != 1 else ''}"
        if self._oros_pendientes is not None:
            respuesta = self._oros_pendientes
            self._oros_pendientes = None
        else:
            respuesta = self._pedir("pago_oro", opciones, {"titulo": titulo, "cantidad": cantidad})
        ids = {int(x) for x in respuesta}
        return [x for x in disponibles if x.uid in ids][:cantidad]

    def elegir_atacantes(self, p, yo, candidatos):
        opciones = [_carta(x, p) for x in candidatos]
        ids = {int(x) for x in self._pedir("atacantes", opciones, {"titulo": "Declara tus atacantes"})}
        return [x for x in candidatos if x.uid in ids]

    def elegir_bloqueos(self, p, yo, atacantes, bloqueadores):
        opciones = [{"atacante": _carta(a, p), "bloqueadores": [_carta(b, p) for b in bloqueadores]} for a in atacantes]
        elegidos = self._pedir("bloqueos", opciones, {"titulo": "Declara tus bloqueos"}) or {}
        por_uid = {x.uid: x for x in bloqueadores}
        usados: set[int] = set()
        out = {}
        for atacante in atacantes:
            uid = elegidos.get(str(atacante.uid))
            if uid is not None and int(uid) in por_uid and int(uid) not in usados:
                out[atacante.uid] = por_uid[int(uid)]
                usados.add(int(uid))
        return out

    def elegir_objetivos(self, p, yo, candidatos, n, h):
        opciones = [_carta(x, p) for x in candidatos]
        ids = {int(x) for x in self._pedir("objetivos", opciones, {"titulo": "Elige objetivo", "cantidad": n})}
        return [x for x in candidatos if x.uid in ids][:n]

    def elegir_descartes(self, p, yo, mano, n):
        opciones = [_carta(x, p) for x in mano]
        ids = {int(x) for x in self._pedir("descartes", opciones, {"titulo": "Elige cartas para descartar", "cantidad": n})}
        return [x for x in mano if x.uid in ids][:n]

    def usar_opcional(self, p, yo, fuente, h):
        return self._pedir("confirmar", [], {"titulo": f"¿Usar habilidad de {fuente.nombre}?"}) == "si"

    def anular(self, p, yo, carta, opciones):
        datos = [{"id": str(k), "titulo": x.nombre, "cartaUid": str(x.uid),
                  "cantidadPago": self._coste_pendiente(p, yo, x) if x.zona.value == "mano" else 0}
                 for k, (x, _) in enumerate(opciones)]
        r = self._respuesta_con_pago("anular", datos, {
            "titulo": f"¿Anular {carta.nombre}?",
            "oros": [_carta(x, p) for x in p.j(yo).reserva],
        })
        return int(r) if r not in (None, "", "pasar") else None

    def responder(self, p, yo, carta, opciones):
        datos = [{"id": str(k), "titulo": x.nombre, "cartaUid": str(x.uid),
                  "cantidadPago": self._coste_pendiente(p, yo, x)}
                 for k, (x, _) in enumerate(opciones)]
        r = self._respuesta_con_pago("responder", datos, {
            "titulo": f"¿Responder a {carta.nombre}?",
            "oros": [_carta(x, p) for x in p.j(yo).reserva],
        })
        return int(r) if r not in (None, "", "pasar") else None

    def preferir_alternativo(self, p, yo, fuente, h):
        return self._pedir("confirmar", [], {
            "titulo": f"¿Pagar el costo alternativo de {fuente.nombre}?"
        }) == "si"

    def redirigir(self, p, yo, objetivo, opciones):
        datos = [{"id": str(k), "titulo": x.nombre} for k, x in enumerate(opciones)]
        r = self._pedir("redirigir", datos, {"titulo": "¿Redirigir el efecto?"})
        return int(r) if r not in (None, "", "pasar") else None

    def elegir_raza(self, p, yo, razas, h):
        return self._pedir("raza", [{"id": x, "titulo": x} for x in razas], {"titulo": "Elige una raza"})

    def elegir_carta(self, p, yo, nombres):
        return self._pedir("carta", [{"id": x, "titulo": x} for x in nombres], {"titulo": "Nombra una carta"})

    def elegir_portador(self, p, yo, arma, portadores):
        opciones = [_carta(x, p) for x in portadores]
        uid = int(self._pedir("portador", opciones, {"titulo": f"¿Quién porta {arma.nombre}?"}))
        return next(x for x in portadores if x.uid == uid)


def respuesta_valida(tipo: str, opciones: list[dict], config: dict, valor: Any) -> bool:
    """Rechaza entradas viejas o inválidas antes de reanudar el motor."""
    ids = {str(o["id"]) for o in opciones if "id" in o}
    if tipo in ("jugada", "anular", "responder") and isinstance(valor, dict):
        opcion = next((o for o in opciones if str(o.get("id")) == str(valor.get("id"))), None)
        if opcion is None or set(valor) != {"id", "oros"}:
            return False
        oros = valor["oros"]
        disponibles = {str(o["id"]) for o in config.get("oros", [])}
        cantidad = int(opcion.get("cantidadPago", 0))
        return (isinstance(oros, list) and len(oros) == cantidad
                and len({str(x) for x in oros}) == cantidad
                and all(str(x) in disponibles for x in oros))
    if tipo in ("mano_inicial", "confirmar"):
        return valor in (("quedarse", "mulligan") if tipo == "mano_inicial" else ("si", "no"))
    if tipo == "avance_fase":
        return valor == "continuar"
    if tipo in ("anular", "responder", "redirigir") and valor == "pasar":
        return True
    if tipo == "bloqueos":
        atacantes = {str(o["atacante"]["id"]) for o in opciones}
        permitidos = {
            str(o["atacante"]["id"]): {str(b["id"]) for b in o["bloqueadores"]}
            for o in opciones
        }
        return isinstance(valor, dict) and set(valor) <= atacantes and all(
            str(b) in permitidos[str(a)] for a, b in valor.items() if b is not None
        ) and len({str(b) for b in valor.values() if b is not None}) == len(
            [b for b in valor.values() if b is not None]
        )
    if tipo in ("atacantes", "objetivos", "descartes", "pago_oro"):
        if not isinstance(valor, list) or len({str(x) for x in valor}) != len(valor):
            return False
        cantidad = config.get("cantidad")
        return (cantidad is None or len(valor) == cantidad) and all(str(x) in ids for x in valor)
    if tipo in ("jugada", "anular", "responder"):
        opcion = next((o for o in opciones if str(o.get("id")) == str(valor)), None)
        # Compatibilidad con clientes Android anteriores: ellos confirman la
        # jugada primero y reciben luego la decisión separada de pago_oro.
        return isinstance(valor, str) and opcion is not None
    return isinstance(valor, str) and valor in ids


class GrabadorIa:
    """Registra las decisiones estratégicas de la heurística para auditarlas."""

    def __init__(self, politica, registrar: Callable[[int, str, list[dict], Any], None]):
        self.politica = politica
        self.registrar = registrar

    def __getattr__(self, nombre):
        return getattr(self.politica, nombre)

    def elegir_jugada(self, p, yo, jugadas):
        elegida = self.politica.elegir_jugada(p, yo, jugadas)
        opciones = [{"id": str(k), "titulo": str(x)} for k, x in enumerate(jugadas)]
        self.registrar(yo, "jugada", opciones, str(jugadas.index(elegida)))
        return elegida

    def elegir_atacantes(self, p, yo, candidatos):
        elegidos = self.politica.elegir_atacantes(p, yo, candidatos)
        opciones = [_carta(x, p) for x in candidatos]
        self.registrar(yo, "atacantes", opciones, [str(x.uid) for x in elegidos])
        return elegidos

    def elegir_bloqueos(self, p, yo, atacantes, bloqueadores):
        elegidos = self.politica.elegir_bloqueos(p, yo, atacantes, bloqueadores)
        opciones = [{"atacante": _carta(a, p), "bloqueadores": [_carta(b, p) for b in bloqueadores]} for a in atacantes]
        self.registrar(yo, "bloqueos", opciones, {str(a): str(b.uid) for a, b in elegidos.items()},
                       analisis=getattr(self.politica, "ultimo_analisis", None))
        return elegidos

    def elegir_objetivos(self, p, yo, candidatos, n, h):
        elegidos = self.politica.elegir_objetivos(p, yo, candidatos, n, h)
        self.registrar(yo, "objetivos", [_carta(x, p) for x in candidatos], [str(x.uid) for x in elegidos])
        return elegidos


def politica_ia_para(mazo_humano, mazo_ia, seed: int,
                    registro_path: Path | None = None):
    """Usa aprendizaje solo si las dos barajas coinciden con un cruce aprobado."""
    ruta = registro_path or CACHE / "entrenamiento" / "modelos" / "djoser_registro_v2.json"
    if not ruta.exists():
        return Heuristico(seed)
    registro = json.loads(ruta.read_text(encoding="utf-8"))
    return jugador_para(registro, ruta.parent, mazo_ia, mazo_humano, seed)


class SesionDesafio:
    """Ejecuta una sesión y bloquea solo su hilo mientras espera a la app."""

    def __init__(self, ref, mazo_humano, mazo_ia, *, seed: int,
                 buscar_bloqueos: bool = False):
        self.ref = ref
        self.mazo_humano = mazo_humano
        self.mazo_ia = mazo_ia
        self.secuencia = 0
        self.decisiones: list[dict[str, Any]] = []
        self.humano = HumanoRemoto(self.pedir)
        self.politica_base_ia = politica_ia_para(mazo_humano, mazo_ia, seed * 2 + 1)
        self.politica_ia = self.politica_base_ia
        if buscar_bloqueos:
            self.politica_ia = PoliticaConBusqueda(self.politica_ia, seed * 2 + 1)
        self.partida = Partida(
            (mazo_humano.cartas, mazo_ia.cartas),
            (self.humano, GrabadorIa(self.politica_ia, self.registrar)),
            nombres=(mazo_humano.nombre, mazo_ia.nombre),
            inicial=None,
            seed=seed,
            log=True,
        )

    def registrar(self, lado: int, tipo: str, opciones: list[dict], elegida: Any,
                  *, analisis: dict | None = None) -> None:
        """Traza compacta. Conserva las alternativas sin llenar Firestore."""
        if len(self.decisiones) >= 500:
            return
        self.decisiones.append({
            "paso": len(self.decisiones) + 1,
            "quien": "Tú" if lado == 0 else "IA",
            "lado": lado,
            "turno": self.partida.e.turno,
            "fase": self.partida.e.fase,
            "tipo": tipo,
            "opciones": opciones[:30],
            "elegida": elegida,
            **({"analisisBloqueos": analisis} if analisis is not None else {}),
            "narracion": (self.partida.e.log or [])[-1] if self.partida.e.log else "",
        })

    def pedir(self, tipo: str, opciones: list[dict], config: dict) -> Any:
        self.secuencia += 1
        decision = str(self.secuencia)
        reintentar_red(lambda: self.ref.update({
            "status": "esperando",
            "decision": {"id": decision, "tipo": tipo, "opciones": opciones, **config},
            "estado": vista_desafio(self.partida, 0),
            "respuesta": None,
        }))
        while True:
            data = reintentar_red(lambda: self.ref.get()).to_dict() or {}
            respuesta = data.get("respuesta") or {}
            if str(respuesta.get("decisionId")) == decision:
                valor = respuesta.get("valor")
                if not respuesta_valida(tipo, opciones, config, valor):
                    reintentar_red(lambda: self.ref.update({
                        "respuesta": None, "errorDecision": "Selección inválida; vuelve a elegir."
                    }))
                    continue
                reintentar_red(lambda: self.ref.update({"status": "jugando", "respuesta": None}))
                self.registrar(0, tipo, opciones, valor)
                return valor
            if data.get("status") == "abandonado":
                raise RuntimeError("Desafío abandonado por el jugador")
            time.sleep(0.35)

    def jugar(self) -> dict:
        registro = self.partida.jugar()
        ganador = self.partida.e.jugadores[registro.ganador].nombre_mazo if registro.ganador in (0, 1) else "Empate"
        nombres = {"J0": self.mazo_humano.nombre, "J1": self.mazo_ia.nombre}
        pasos = []
        for paso in self.partida.pasos[:1500]:
            texto = paso["x"]
            for codigo, nombre in nombres.items():
                texto = texto.replace(codigo, nombre)
            pasos.append({**paso, "x": texto})
        cartas = {c.id: c.nombre for c in self.mazo_humano.cartas + self.mazo_ia.cartas}
        cartas["oro_inicial"] = "Oro inicial"
        return {
            "ganador": ganador,
            "ganadorLado": registro.ganador,
            "turnos": registro.turnos,
            "causa": registro.causa,
            "politicaIa": self.politica_ia.nombre,
            "politicaBaseIa": self.politica_base_ia.nombre,
            "narracion": (self.partida.e.log or [])[-1000:],
            "decisiones": self.decisiones,
            "estado": vista_desafio(self.partida, 0),
            "repeticion": {
                "mazoA": {"nombre": self.mazo_humano.nombre},
                "mazoB": {"nombre": self.mazo_ia.nombre},
                "cartas": _sin_ids_reservados(cartas),
                "pasos": _sin_ids_reservados(_solo_cambios(pasos)),
            },
        }
